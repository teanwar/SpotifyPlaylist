# SpotifyPlaylist
Select multiple artists to create a playlist with their songs 


Environment:

Install python3
Installed spotipy --- [python3 -m install spotipy] 


(NOTE: It's not completed yet)
